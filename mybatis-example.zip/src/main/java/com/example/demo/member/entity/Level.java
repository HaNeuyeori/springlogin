package com.example.demo.member.entity;


// Level level = Level.NORMAL;
// System.out.println(level.name());

public enum Level {
	NORMAL("일반회원"), SILVER("우수회원"), GOLD("VIP회원");

	Level(String string) {
	}
}

package com.example.demo.member.dao;

import org.mybatis.spring.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import com.example.demo.member.entity.*;

@Repository
public class MemberDao {
	@Autowired
	private SqlSessionTemplate tpl;
	
	public Boolean existsByUsername(String username) {
		return tpl.selectOne("memberMapper.existsByUsername", username);
	}
	
	public Integer save(Member member) {
		return tpl.insert("memberMapper.save", member);
	}
	
	public String findUsernameByEmail(String email) {
		return tpl.selectOne("memberMapper.findUsernameByEmail", email);
	}
	
	public Member findById(String username) {
		return tpl.selectOne("memberMapper.findById", username);
	}
	
	public Integer changePassword(Member member) {
		return tpl.update("memberMapper.changePassword", member);
	}
	
	public Integer changeEmail(Member member) {
		return tpl.update("memberMapper.changeEmail", member);
	}
	
	public Integer delete(String loginId) {
		return tpl.delete("memberMapper.delete", loginId);
	}
}









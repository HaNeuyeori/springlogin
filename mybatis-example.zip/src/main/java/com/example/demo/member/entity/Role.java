package com.example.demo.member.entity;

// 스프링 시큐리티에서 사용자 권한으로 사용한 enum
public enum Role {
	USER, ADMIN;
}

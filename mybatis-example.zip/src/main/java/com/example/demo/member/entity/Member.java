package com.example.demo.member.entity;

import java.time.*;
import java.time.format.*;
import java.time.temporal.*;

import com.example.demo.dto.*;

import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Member {
	private String username;
	private String password;
	private String email;
	private LocalDate birthday;
	private LocalDate joinday;
	
	public MemberDto.Read toReadDto() {
		MemberDto.Read dto = MemberDto.Read.builder().username(username).email(email).build();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy년 MM월 dd일");
		dto.setJoinday(dtf.format(joinday));
		dto.setBirthday(dtf.format(birthday));
		dto.setDays(ChronoUnit.DAYS.between(joinday, LocalDate.now()));
		return dto;
	}
}

















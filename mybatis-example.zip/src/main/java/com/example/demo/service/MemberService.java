package com.example.demo.service;

import org.apache.commons.lang3.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import com.example.demo.dto.*;
import com.example.demo.member.dao.*;
import com.example.demo.member.entity.*;

@Service
public class MemberService {
	@Autowired
	private MemberDao memberDao;
	
	public Boolean checkUsername(String username) {
		return memberDao.existsByUsername(username);
	}

	public Boolean join(Member member) {
		return memberDao.save(member)==1;
	}

	public Boolean login(String username, String password) {
		Member member = memberDao.findById(username);
		// 검색 결과가 없으면 null이 리턴된다. 널 체크를 잊으면 안됨
		if(member==null)
			return false;
		return member.getPassword().equals(password);
	}
	
	public String findId(String email) {
		return memberDao.findUsernameByEmail(email);
	}

	public String 임시비밀번호발급(String username, String email) {
		Boolean result = memberDao.findById(username).getEmail().equals(email);
		if(result==false)
			return null;
		// String 임시비밀번호 = RandomStringUtils.randomAlphanumeric(20);
		String 임시비밀번호 = "9999";
		if(memberDao.changePassword(Member.builder().username(username).password(임시비밀번호).build())==1)
			return 임시비밀번호;
		else
			return null;
	}

	public Boolean checkPassword(String password, String username) {
		return memberDao.findById(username).getPassword().equals(password);
	}

	public MemberDto.Read read(String username) {
		Member member = memberDao.findById(username);
		return member.toReadDto();
	}

	public void quit(String username) {
		memberDao.delete(username);
	}
}

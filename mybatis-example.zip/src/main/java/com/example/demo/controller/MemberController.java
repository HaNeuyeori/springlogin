package com.example.demo.controller;

import javax.servlet.http.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.stereotype.*;
import org.springframework.ui.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.*;
import org.springframework.web.servlet.mvc.support.*;

import com.example.demo.dto.*;
import com.example.demo.service.*;

// 화면을 보여주거나 이동한다 : MVC -> return을 void 또는 String
//						  Model에 데이터를 담고 View를 리턴
// 현재 화면에 머문다 : REST -> return을 ResponseEntity 객체(데이터 + 상태코드)

@Controller
public class MemberController {
	@Autowired
	private MemberService memberService;
	
	@GetMapping("/")
	public ModelAndView index() {
		return new ModelAndView("list");
	}
	
	// a. 회원 가입 화면 보여주기
	@GetMapping("/member/join")
	public void join() {
	}
	
	// a-1. 아이디 중복 확인
	@GetMapping("/member/check/username/{username}")
	public ResponseEntity<Void> checkUsername(@PathVariable String username) {
		Boolean result = memberService.checkUsername(username);
		if(!result)
			return ResponseEntity.ok(null);
		return ResponseEntity.status(HttpStatus.CONFLICT).body(null);
	}
	
	// a-2.회원 가입
	@PostMapping("/member/join")
	public String save(@ModelAttribute MemberDto.Create dto) {
		memberService.join(dto.toEntity());
		return "redirect:/member/login";
	}
	
	// b. 아이디, 비밀번호 찾기 
	@GetMapping("/member/find")
	public void find() {
	}
	
	// b-3. 아이디 찾기 : 찾으면 200 + 아이디를, 못찾으면 409를 응답
	@GetMapping("/member/find_id")
	public ResponseEntity<String> findId(@RequestParam String email) {
		String username = memberService.findId(email);
		if(username==null)
			return ResponseEntity.status(HttpStatus.CONFLICT).body(null);
		return ResponseEntity.ok(username);
	}
	
	// b-4. 임시비밀번호 발급 : 비밀번호를 찾으면 200 + 임시비밀번호를, 못찾으면 409를 응답
	@PostMapping("/member/reset_password")
	public ResponseEntity<String> 임시비밀번호발급(@RequestParam String username, @RequestParam String email) {
		String 임시비밀번호 = memberService.임시비밀번호발급(username, email);
		if(임시비밀번호==null)
			return ResponseEntity.status(HttpStatus.CONFLICT).body(null);
		return ResponseEntity.ok(임시비밀번호);
	}
	
	// c. 로그인 화면
	@GetMapping("/member/login")
	public void login(HttpSession session, Model model) {
		// 1. 로그인 페이지에 처음 접근한 경우 - 바로 로그인 화면 출력
		// 2. 로그인 오류가 발생해 로그인 페이지에 다시 접근한 경우
		//    - 세션에 담긴 메시지는 삭제할 때까지 계속 유지된다 -> jsp에서 오류 메시지가 계속 출력된다
		//	  - 세션에 담긴 메시지를 Model에 옮긴 다음 삭제한다
		//	  - Model은 jsp 출력 후 자동으로 파괴된다
		if(session.getAttribute("msg")!=null) {
			model.addAttribute("msg", session.getAttribute("msg"));
			session.removeAttribute("msg");
		}
	}
	
	// c-5. 로그인 처리
	// 로그인에 성공하면 세션에 성공 정보를 담은 다음 루트 페이지로 간다
	// 로그인에 실패하면 세션에 오류 메시지를 담은 다음 로그인 페이지로 다시 간다
	@PostMapping("/member/login")
	public ModelAndView login(@RequestParam String username, @RequestParam String password, HttpSession session) {
		Boolean result = memberService.login(username, password);
		if(result) {
			session.setAttribute("username", username);
			return new ModelAndView("redirect:/");
		} else {
			session.setAttribute("msg", "로그인에 실패했습니다");
			return new ModelAndView("redirect:/member/login");
		}
	}
	
	// c-6. 로그아웃
	@PostMapping("/member/logout")
	public ModelAndView logout(HttpSession session) {
		// 로그인하지 않은 경우 로그인으로 이동
		if(session.getAttribute("username")==null) 
			return new ModelAndView("redirect:/member/login");
		// 세션을 날려서 로그아웃 시킨 다음 루트 페이지로 이동
		session.invalidate();
		return new ModelAndView("redirect:/");
	}
	
	// d-7. 비밀번호 확인
	//    로그인 안했으면 로그인으로 이동 -> 비밀번호 이미 했으면 내정보 보기로 이동 -> 비밀번호 입력 화면
	@GetMapping("/member/check_password")
	public ModelAndView check_password(HttpSession session) {
		if(session.getAttribute("username")==null) 
			return new ModelAndView("redirect:/member/login");
		
		if(session.getAttribute("checkPassword")!=null)
			return new ModelAndView("redirect:/member/read");
		
		return new ModelAndView("member/check_password");
	}
	
	// d-8. 비밀번호 확인
	@PostMapping("/member/check_password")
	public ModelAndView check_password(@RequestParam String password, HttpSession session, RedirectAttributes ra) {
		if(session.getAttribute("username")==null) 
			return new ModelAndView("redirect:/member/login");
		if(session.getAttribute("checkPassword")!=null)
			return new ModelAndView("redirect:/member/read");
		
		String username = (String)session.getAttribute("username");
		Boolean result = memberService.checkPassword(password, username);
		
		if(result==false) {
			ra.addFlashAttribute("msg", "비밀번호를 정확하게 입력하세요");
			return new ModelAndView("redirect:/member/check_password");
		} else {
			session.setAttribute("checkPassword", true);
			return new ModelAndView("redirect:/member/check_password");
		}
	}
	
	// e-9. 내정보 보기
	@GetMapping("/member/read")
	public ModelAndView read(HttpSession session) {
		if(session.getAttribute("username")==null) 
			return new ModelAndView("redirect:/member/login");
		if(session.getAttribute("checkPassword")==null)
			return new ModelAndView("redirect:/member/check_password");
		String username = (String)session.getAttribute("username");
		MemberDto.Read dto = memberService.read(username);
		return new ModelAndView("member/read").addObject("member", dto);
	}
		
	// 10. 탈퇴
	@PostMapping("/member/quit")
	public ModelAndView quit(HttpSession session) {
		if(session.getAttribute("username")==null) 
			return new ModelAndView("redirect:/member/login");
		String username = (String)session.getAttribute("username");
		memberService.quit(username);
		return new ModelAndView("redirect:/");
	}
}
